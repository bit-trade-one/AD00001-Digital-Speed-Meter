extern unsigned char op_demo(unsigned int,char);
